GOOD NEARBY — GITHUB PAGES FIX
Repairs ZIP search, Search button/Enter behavior, and filter controls for the GitHub Pages build.
